/*
 * $Id: template.c,v 1.1.1.1 1999/04/17 22:16:31 morgan Exp $
 *
 * Copyright (c) 1997 <Author>  <@>
 *
 * <Content>
 */

/*
 * $Log: template.c,v $
 * Revision 1.1.1.1  1999/04/17 22:16:31  morgan
 * release 1.0 of libcap
 *
 */

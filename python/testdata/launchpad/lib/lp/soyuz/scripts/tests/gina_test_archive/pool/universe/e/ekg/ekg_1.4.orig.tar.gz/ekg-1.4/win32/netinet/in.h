/*
 * <netinet/in.h>
 *
 * obs�uga sieci.
 *
 * $Id: in.h,v 1.2 2002/08/07 14:37:08 wojtekka Exp $
 */

#include <winsock2.h>

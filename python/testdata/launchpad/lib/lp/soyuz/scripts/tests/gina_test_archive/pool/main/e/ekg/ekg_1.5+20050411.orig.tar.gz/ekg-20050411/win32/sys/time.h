/*
 * <sys/time.h>
 *
 * brakuje tego na win32.
 *
 * $Id: time.h,v 1.2 2002/08/07 14:37:08 wojtekka Exp $
 */

